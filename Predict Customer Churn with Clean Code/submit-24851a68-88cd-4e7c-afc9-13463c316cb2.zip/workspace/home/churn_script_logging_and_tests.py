"""
churn_script_logging_and_tests.py
Author: Pranav Arya
Date: 18/12/2025
Testing and logging for churn_library.py
"""

import logging
import os
import churn_library as cl

os.makedirs("./logs", exist_ok=True)

logging.basicConfig(
    filename="./logs/churn_library.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


def test_import():
    """
    Test data import
    """
    try:
        df = cl.import_data("./data/bank_data.csv")
        assert df.shape[0] > 0
        assert df.shape[1] > 0
        logging.info("test_import: SUCCESS")
    except Exception as err:
        logging.error("test_import: FAILED")
        raise err


def test_eda():
    """
    Test perform_eda function
    """
    try:
        df = cl.import_data("./data/bank_data.csv")
        df["Churn"] = df["Attrition_Flag"].apply(
            lambda x: 0 if x == "Existing Customer" else 1
        )

        cl.perform_eda(df)

        assert os.path.exists("./images/eda")
        assert len(os.listdir("./images/eda")) > 0
        logging.info("test_eda: SUCCESS")
    except Exception as err:
        logging.error("test_eda: FAILED")
        raise err


def test_encoder_helper():
    """
    Test encoder_helper function
    """
    try:
        df = cl.import_data("./data/bank_data.csv")
        df["Churn"] = df["Attrition_Flag"].apply(
            lambda x: 0 if x == "Existing Customer" else 1
        )

        df_encoded = cl.encoder_helper(df, ["Gender"], "Churn")

        assert "Gender_Churn" in df_encoded.columns
        assert df_encoded["Gender_Churn"].isnull().sum() == 0
        logging.info("test_encoder_helper: SUCCESS")
    except Exception as err:
        logging.error("test_encoder_helper: FAILED")
        raise err


def test_perform_feature_engineering():
    """
    Test perform_feature_engineering function
    """
    try:
        df = cl.import_data("./data/bank_data.csv")
        df["Churn"] = df["Attrition_Flag"].apply(
            lambda x: 0 if x == "Existing Customer" else 1
        )

        X_train, X_test, y_train, y_test = cl.perform_feature_engineering(
            df, "Churn"
        )

        assert X_train.shape[0] > 0
        assert X_test.shape[0] > 0
        assert y_train.shape[0] > 0
        assert y_test.shape[0] > 0
        logging.info("test_perform_feature_engineering: SUCCESS")
    except Exception as err:
        logging.error("test_perform_feature_engineering: FAILED")
        raise err


def test_train_models():
    """
    Test train_models function
    """
    try:
        df = cl.import_data("./data/bank_data.csv")
        df["Churn"] = df["Attrition_Flag"].apply(
            lambda x: 0 if x == "Existing Customer" else 1
        )

        X_train, X_test, y_train, y_test = cl.perform_feature_engineering(
            df, "Churn"
        )

        cl.train_models(X_train, X_test, y_train, y_test)

        assert os.path.exists("./models/rfc_model.pkl")
        assert os.path.exists("./models/logistic_model.pkl")
        logging.info("test_train_models: SUCCESS")
    except Exception as err:
        logging.error("test_train_models: FAILED")
        raise err


if __name__ == "__main__":
    test_import()
    test_eda()
    test_encoder_helper()
    test_perform_feature_engineering()
    test_train_models()
