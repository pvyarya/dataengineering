# Predict Customer Churn

- Project **Predict Customer Churn** of ML DevOps Engineer Nanodegree Udacity

## Project Description
This project identifies credit card customers who are most likely to churn using machine learning models, while strictly applying PEP8 coding standards and software engineering best practices.
It refactors a Jupyter notebook into Python modules with testing, logging, and best engineering practices that can be executed either interactively or via the command-line interface.

## Files and data description
├── Guide.ipynb          # Given: Getting started and troubleshooting tips
├── churn_notebook.ipynb # Given: Contains the code to be refactored
├── churn_library.py     # Define the functions
├── churn_script_logging_and_tests.py # ToDo: Finish tests and logs
├── README.md            # Provides project overview, and instructions to use the code
├── data                 # Read this data
│   └── bank_data.csv
├── images               # Store EDA results 
│   ├── eda
│   └── results
├── logs				 # Store logs
└── models               # Store models

## Running Files
Manually install dependencies:

python -m pip install -r requirements_py3.6.txt

Run ML Pipleine:
ipython churn_library.py

Run Tests and Logging:
ipython churn_script_logging_and_tests.py

Formatting:
autopep8 --in-place --aggressive --aggressive churn_script_logging_and_tests.py
autopep8 --in-place --aggressive --aggressive churn_library.py

Linting:
pylint churn_library.py
pylint churn_script_logging_and_tests.py



