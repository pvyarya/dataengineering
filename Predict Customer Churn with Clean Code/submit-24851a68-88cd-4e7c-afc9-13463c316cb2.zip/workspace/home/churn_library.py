"""
churn_library.py
Author: Pranav Arya
Date: 18/12/2025
Library of functions for predicting customer churn.
"""

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, plot_roc_curve

import os
os.environ['QT_QPA_PLATFORM']='offscreen'



def import_data(pth):
    '''
    returns dataframe for the csv found at pth

    input:
            pth: a path to the csv
    output:
            df: pandas dataframe
    '''	
    return pd.read_csv(pth)


def perform_eda(df):
    '''
    perform eda on df and save figures to images folder
    input:
            df: pandas dataframe

    output:
            None
    '''
    os.makedirs("./images/eda", exist_ok=True)

    df['Churn'].hist()
    plt.savefig("./images/eda/churn_distribution.png")
    plt.close()

    df['Customer_Age'].hist()
    plt.savefig("./images/eda/customer_age.png")
    plt.close()

    df['Marital_Status'].value_counts('normalize').plot(kind='bar')
    plt.savefig("./images/eda/marital_status.png")
    plt.close()

    df['Total_Trans_Ct'].hist()
    plt.savefig("./images/eda/total_trans_ct.png")
    plt.close()

    plt.figure(figsize=(20, 10))
    plt.imshow(df.corr(), cmap='coolwarm')
    plt.colorbar()
    plt.savefig("./images/eda/correlation_heatmap.png")
    plt.close()


def encoder_helper(df, category_lst, response):
    '''
    helper function to turn each categorical column into a new column with
    propotion of churn for each category - associated with cell 15 from the notebook

    input:
            df: pandas dataframe
            category_lst: list of columns that contain categorical features
            response: string of response name [optional argument that could be used for naming variables or index y column]

    output:
            df: pandas dataframe with new columns for
    '''
    for col in category_lst:
        means = df.groupby(col)[response].mean()
        df[f"{col}_Churn"] = df[col].map(means)
    return df


def perform_feature_engineering(df, response):
    '''
    input:
              df: pandas dataframe
              response: string of response name [optional argument that could be used for naming variables or index y column]

    output:
              X_train: X training data
              X_test: X testing data
              y_train: y training data
              y_test: y testing data
    '''
    y = df[response]

    cat_cols = [
        'Gender',
        'Education_Level',
        'Marital_Status',
        'Income_Category',
        'Card_Category'
    ]

    df = encoder_helper(df, cat_cols, response)

    keep_cols = [
        'Customer_Age',
        'Dependent_count',
        'Months_on_book',
        'Total_Relationship_Count',
        'Months_Inactive_12_mon',
        'Contacts_Count_12_mon',
        'Credit_Limit',
        'Total_Revolving_Bal',
        'Avg_Open_To_Buy',
        'Total_Amt_Chng_Q4_Q1',
        'Total_Trans_Amt',
        'Total_Trans_Ct',
        'Total_Ct_Chng_Q4_Q1',
        'Avg_Utilization_Ratio',
        'Gender_Churn',
        'Education_Level_Churn',
        'Marital_Status_Churn',
        'Income_Category_Churn',
        'Card_Category_Churn'
    ]

    X = df[keep_cols]

    return train_test_split(X, y, test_size=0.3, random_state=42)

def classification_report_image(y_train,
                                y_test,
                                y_train_preds_lr,
                                y_train_preds_rf,
                                y_test_preds_lr,
                                y_test_preds_rf):
    '''
    produces classification report for training and testing results and stores report as image
    in images folder
    input:
            y_train: training response values
            y_test:  test response values
            y_train_preds_lr: training predictions from logistic regression
            y_train_preds_rf: training predictions from random forest
            y_test_preds_lr: test predictions from logistic regression
            y_test_preds_rf: test predictions from random forest

    output:
             None
    '''
    os.makedirs("./images/results", exist_ok=True)

    def plot_report(text, filename):
        plt.figure(figsize=(5, 5))
        plt.text(0.01, 0.05, text, {'fontsize': 10}, fontproperties='monospace')
        plt.axis('off')
        plt.savefig(filename)
        plt.close()

    plot_report(
        classification_report(y_train, y_train_preds_rf),
        "./images/results/rf_train_report.png"
    )
    plot_report(
        classification_report(y_test, y_test_preds_rf),
        "./images/results/rf_test_report.png"
    )
    plot_report(
        classification_report(y_train, y_train_preds_lr),
        "./images/results/lr_train_report.png"
    )
    plot_report(
        classification_report(y_test, y_test_preds_lr),
        "./images/results/lr_test_report.png"
    )


def feature_importance_plot(model, X_data, output_pth):
    '''
    creates and stores the feature importances in pth
    input:
            model: model object containing feature_importances_
            X_data: pandas dataframe of X values
            output_pth: path to store the figure

    output:
             None
    '''
    importances = model.feature_importances_
    indices = np.argsort(importances)[::-1]
    names = X_data.columns[indices]

    plt.figure(figsize=(20, 5))
    plt.title("Feature Importance")
    plt.bar(range(len(importances)), importances[indices])
    plt.xticks(range(len(importances)), names, rotation=90)
    plt.savefig(output_pth)
    plt.close()

def train_models(X_train, X_test, y_train, y_test):
    '''
    train, store model results: images + scores, and store models
    input:
              X_train: X training data
              X_test: X testing data
              y_train: y training data
              y_test: y testing data
    output:
              None
    '''
    os.makedirs("./models", exist_ok=True)

    rfc = RandomForestClassifier(random_state=42)
    lrc = LogisticRegression(max_iter=3000)

    param_grid = {
        'n_estimators': [200, 500],
        'max_depth': [4, 5, 100],
        'criterion': ['gini', 'entropy']
    }

    cv_rfc = GridSearchCV(rfc, param_grid, cv=5)
    cv_rfc.fit(X_train, y_train)
    lrc.fit(X_train, y_train)

    y_train_rf = cv_rfc.best_estimator_.predict(X_train)
    y_test_rf = cv_rfc.best_estimator_.predict(X_test)
    y_train_lr = lrc.predict(X_train)
    y_test_lr = lrc.predict(X_test)

    classification_report_image(
        y_train, y_test,
        y_train_lr, y_train_rf,
        y_test_lr, y_test_rf
    )

    plot_roc_curve(lrc, X_test, y_test)
    plot_roc_curve(cv_rfc.best_estimator_, X_test, y_test)
    plt.savefig("./images/results/roc_curve.png")
    plt.close()

    feature_importance_plot(
        cv_rfc.best_estimator_,
        X_train,
        "./images/results/feature_importance.png"
    )

    joblib.dump(cv_rfc.best_estimator_, "./models/rfc_model.pkl")
    joblib.dump(lrc, "./models/logistic_model.pkl")