# Sparkify Data Warehouse ETL Project

## Project Overview

A music streaming startup, Sparkify, has grown their user base and song database and want to move their processes and data onto the cloud. Their data resides in S3, in a directory of JSON logs on user activity on the app, as well as a directory with JSON metadata on the songs in their app.

The goal of this project is building an ETL pipeline that extracts their data from S3, stages them in Redshift, and transforms data into a set of dimensional tables for their analytics team to continue finding insights into what songs their users are listening to.



This database allows Sparkify's analytics team to answer questions like:

- Which songs are most popular?
- Who are the most active users?
- What are peak listening times?
- How do free vs. paid users engage with songs?

## Database Schema

We designed a star schema for the song play analysis, consisting of:

### Fact Table
**songplays**
- `songplay_id` (PK)
- `start_time` (FK - time)
- `user_id` (FK - users)
- `level`
- `song_id` (FK - songs)
- `artist_id` (FK - artists)
- `session_id`
- `location`
- `user_agent`

### Dimension Tables
**users** - users in the app
- `user_id` (PK)
- `first_name`
- `last_name`
- `gender`
- `level`

**songs** - songs in music database
- `song_id` (PK)
- `title`
- `artist_id` (FK - artists)
- `year`
- `duration`

**artists** – artists in music database
- `artist_id` (PK)
- `name`
- `location`
- `latitude`
- `longitude`

**time** – timestamps of records in songplays broken down into specific units
- `start_time` (PK)
- `hour`
- `day`
- `week`
- `month`
- `year`
- `weekday`

This schema allows fast queries on song plays, user behavior, and song/artist trends.



## ETL Pipeline

The ETL pipeline follows these steps:

1. **Staging Data**  
   - COPY JSON data from S3 into `staging_events` and `staging_songs`.
   - JSON logs are parsed using `log_json_path.json`.

2. **Transformations**  
   - Extract necessary columns from staging tables.
   - Convert timestamps to proper format.
   - Join staging tables to populate the songplays fact table.
   - Insert distinct values into dimension tables to avoid duplicates.

3. **Analytics Tables**  
   - Populate `songplays`, `users`, `songs`, `artists`, and `time`.
   - Supports queries like top songs, peak listening times, and user activity.



## How to Run the Project

1. **Setup AWS Resources**
   - Create an IAM role with AmazonS3ReadOnlyAccess.
   - Create a Security Group.
   - Create an IAM User.
   - Attach the role to the cluster & Launch Redshift Cluster.

2. **Update `dwh.cfg`**
   - Fill in cluster endpoint, database, user, password, port, IAM role ARN, and S3 locations.

3. **Create Tables**
In terminal, run:
python create_tables.py


4. **Run ETL Pipeline**
In terminal, runL
python etl.py


5. **Verify Results**

Query Redshift tables for row counts.

Run analytics queries to check joins and star schema.
   

   
## In this repository

**create_tables.py**  
Connects to Redshift, drops existing tables, and creates staging and star schema tables.

**etl.py**  
Executes the ETL pipeline: loads S3 data into staging, transforms it, and populates analytics tables.

**sql_queries.py**  
Contains SQL statements for dropping, creating, copying, and inserting tables.
   
**dwh.cfg**  
Configuration file with AWS credentials, Redshift cluster info, IAM role, and S3 paths.



