import configparser
import psycopg2
from sql_queries import copy_table_queries, insert_table_queries


def load_staging_tables(cur, conn):
    """
    Load data from S3 into Redshift staging tables using COPY commands.
    """
    print("Loading staging tables...")
    for query in copy_table_queries:
        print(f"Running COPY: {query[:60]}...")
        cur.execute(query)
        conn.commit()
    print("Staging tables loaded.")


def insert_tables(cur, conn):
    """
    Insert data from staging tables into analytics star schema tables.
    """
    print("Inserting into analytics tables...")
    for query in insert_table_queries:
        print(f"Running INSERT: {query[:60]}...")
        cur.execute(query)
        conn.commit()
    print("Analytics tables populated.")


def main():
    """
    Connect to Redshift, load staging tables, then insert analytics tables.
    """
    config = configparser.ConfigParser()
    config.read('dwh.cfg')


    conn = psycopg2.connect(
        "host={} dbname={} user={} password={} port={}".format(
            config.get("CLUSTER", "HOST"),
            config.get("CLUSTER", "DB_NAME"),
            config.get("CLUSTER", "DB_USER"),
            config.get("CLUSTER", "DB_PASSWORD"),
            config.get("CLUSTER", "DB_PORT"),
        )
    )
    cur = conn.cursor()

    load_staging_tables(cur, conn)
    insert_tables(cur, conn)

    conn.close()
    print("ETL pipeline completed successfully!")


if __name__ == "__main__":
    main()
