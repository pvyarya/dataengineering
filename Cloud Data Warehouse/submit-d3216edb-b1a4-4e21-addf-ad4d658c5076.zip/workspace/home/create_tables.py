import configparser
import psycopg2
from sql_queries import create_table_queries, drop_table_queries


def drop_tables(cur, conn):
    """
    Drops each table using the queries in drop_table_queries list.
    Allows pipeline to be rerun cleanly.
    """
    for query in drop_table_queries:
        cur.execute(query)
        conn.commit()


def create_tables(cur, conn):
    """
    Creates staging and analytics tables using queries in create_table_queries list.
    """
    for query in create_table_queries:
        cur.execute(query)
        conn.commit()


def main():
    """
    Connects to Redshift cluster, drops existing tables, and recreates them.
    """
    config = configparser.ConfigParser()
    config.read('dwh.cfg')

    # Connect to Redshift cluster
    conn = psycopg2.connect(
        "host={} dbname={} user={} password={} port={}".format(
            config.get("CLUSTER", "HOST"),
            config.get("CLUSTER", "DB_NAME"),
            config.get("CLUSTER", "DB_USER"),
            config.get("CLUSTER", "DB_PASSWORD"),
            config.get("CLUSTER", "DB_PORT"),
        )
    )
    cur = conn.cursor()


    drop_tables(cur, conn)


    create_tables(cur, conn)

    conn.close()
    print("Tables successfully created")



if __name__ == "__main__":
    main()
